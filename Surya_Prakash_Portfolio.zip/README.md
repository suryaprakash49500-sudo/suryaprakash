# S Surya Prakash Portfolio

A responsive portfolio website built from the resume details provided.

## Files
- `index.html` — website structure and content
- `style.css` — responsive styling
- `script.js` — mobile navigation and current year

## Run locally
Open `index.html` in any modern browser.

## Publish
You can upload these files to GitHub Pages, Netlify, Vercel, or another static hosting service.

## Before publishing
- Verify the phone number and LinkedIn URL.
- Replace the initials avatar with a professional photo if desired.
- Add a GitHub link and live project link when available.
